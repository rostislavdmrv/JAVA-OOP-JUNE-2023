package p02;

public class ElectricVehicleImpl implements Vehicle{
    @Override
    public String drive(double distance) {
        return null;
    }

    @Override
    public void refuel(double liters) {

    }
}
